#ifndef __LOAD_IMAGE_H__
#define __LOAD_IMAGE_H__

#include <iostream>
#include <cv.h>
#include <highgui.h>
#include "class.h"
using namespace std;
using namespace cv;
IplImage* load_image(char* str);
//IplImage* load_image();

#endif