﻿#include <iostream>
#include <cv.h>
#include <highgui.h>
#include "class.h"
#include "contours.h"
#include "load_image.h"
#include "to_binary.h"
#include "to_gray.h"
#include "fractal_dectect.h"
using namespace std;
using namespace cv;

int main(int argc,char** argv)
{
	IplImage* src = NULL;
	IplImage* gray_t = NULL;
    IplImage* binary_t = NULL;
    IplImage* src_c = NULL;
    cv::Mat src_c_temp;//用于IplImage和Mat的转换，便于兼容fractal_dectect（）的函数接口；
	ex_conutour cont_res;
	vector< vector<int> > result_class;
    src=load_image(argv[1]);//加载图像
	gray_t=to_gray(src); //转为灰度图
	binary_t= to_binary(gray_t); //转为二值图
    cont_res=extract_contours(binary_t,src);//轮廓提取
	src_c=CenterClassification(cont_res.squares_centers,cont_res.squares_v,result_class,src); //中心点聚类
	src_c_temp=cvarrToMat(src_c);
    fractal_dectect(src_c_temp);

	cvWaitKey (0);
	cvReleaseImage (&src);
	cvReleaseImage (&binary_t);
	cvReleaseImage (&gray_t);
    return 0;
}

