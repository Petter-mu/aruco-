#include<iostream>
#include<cv.h>
#include<highgui.h>
#include "contours.h"

using namespace std;
using namespace cv;

ex_conutour  extract_contours(IplImage* img,IplImage* src)
{

	int contours_num=0;
	ex_conutour contours_res;
	CvMemStorage* storage = cvCreateMemStorage (0);
	CvMemStorage* storage1 = cvCreateMemStorage (0);
	CvMemStorage* storage2 = cvCreateMemStorage (0);
	CvSeq*  squares = cvCreateSeq(CV_SEQ_ELTYPE_POINT | CV_SEQ_FLAG_CLOSED, sizeof(CvSeq), sizeof(CvPoint), storage2);

	CvSeq* contour = 0;
	CvSeq* cont;
	CvSeq* mcont;
    CvSeqReader reader; 
	CvPoint corner[4]; //�ĸ��ǵ�
	vector<Point> corner_v;//��һ������4������
	vector< vector<Point> > squares_v; 
	vector<Point> squares_centers;
	Point temp;
	Point center;

	IplImage* src_contour = cvCreateImage (cvGetSize(src), src->depth, src->nChannels);
	cvCopy(src,src_contour,NULL);
	cvFindContours (img, storage, &contour, sizeof(CvContour), CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE);
	while(contour)
	{
		CvTreeNodeIterator iterator;
		cvInitTreeNodeIterator (&iterator, contour,  1);
		/*
		while (0 != (cont = (CvSeq*)cvNextTreeNode (&iterator)))
		{
		mcont = cvApproxPoly (cont, sizeof(CvContour), storage1, CV_POLY_APPROX_DP, cvContourPerimeter(cont)*0.02,0);
		//cvDrawContours (dst, mcont, CV_RGB(255,0,0),CV_RGB(255,0,0),1,2,8,cvPoint(0,0));
		cvDrawContours (src, mcont, CV_RGB(255,0,0),CV_RGB(255,0,0),1,1,8,cvPoint(0,0));
		}
		*/
		cont = (CvSeq*)cvNextTreeNode (&iterator);
		mcont = cvApproxPoly (cont, sizeof(CvContour), storage1, CV_POLY_APPROX_DP, cvContourPerimeter(cont)*0.02,0);
		//cvDrawContours (src, mcont, CV_RGB(0,255,0),CV_RGB(255,0,0),1,1,8,cvPoint(0,0));
		
		
		if( fabs(cvContourArea(contour)) > 5 && fabs(cvContourArea(contour))< 204800)   //neglect the small contours
		{
			//findout the squares
			
			
			if( mcont->total == 4  &&  cvCheckContourConvexity(mcont) )  
			{
				cout<<"The contours number is "<<contours_num++<<endl; 
				//cout<<"The square area is "<<fabs(cvContourArea(contour))<<endl;
				cvStartReadSeq( mcont, &reader, 0 );                      
				for( int i = 0; i < 4; i++ )
				{
					
					cvSeqPush( squares,(CvPoint*)cvGetSeqElem( mcont, i ));
					memcpy( corner + i, reader.ptr, mcont->elem_size ); 
					CV_NEXT_SEQ_ELEM( mcont->elem_size, reader );
				}
				for(int i =0; i < 4; i++)    //save the corner points to corner_v, it will help us process the data
				{
					temp = corner[i];
					corner_v.push_back(temp);
				}
				cvLine(src_contour,corner[0],corner[1],cvScalar(0, 255, 0),1,CV_AA,0);
				cvLine(src_contour,corner[1],corner[2],cvScalar(0, 255, 0),1,CV_AA,0);
				cvLine(src_contour,corner[2],corner[3],cvScalar(0, 255, 0),1,CV_AA,0);
				cvLine(src_contour,corner[3],corner[0],cvScalar(0, 255, 0),1,CV_AA,0);
				
				center.x = (corner[0].x + corner[1].x + corner[2].x + corner[3].x) / 4;
				center.y = (corner[0].y + corner[1].y + corner[2].y + corner[3].y) / 4;
				cout<<"The center point is ( "<<center.x<<","<<center.y<<")"<<endl;
				squares_centers.push_back(center);  

				cout<<"The corner_v NO.1 point is"<<corner_v[0]<<endl;
				cout<<"The corner_v NO.2 is"<<corner_v[1]<<endl;
				cout<<"The corner_v NO.3 is"<<corner_v[2]<<endl;
				cout<<"The corner_v NO.4 is"<<corner_v[3]<<endl;
				squares_v.push_back(corner_v);

				corner_v.clear();       
			} 
		}                                     
		contour = contour->h_next;  
			
	
	}
	contours_res.squares_centers=squares_centers;
	contours_res.squares_v=squares_v;
	cvNamedWindow ("Contour", 1);
	cvShowImage ("Contour", src_contour);
	cvReleaseMemStorage (&storage);
	return contours_res;

}