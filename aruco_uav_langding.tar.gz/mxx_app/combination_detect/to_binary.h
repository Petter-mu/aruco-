#ifndef __TO_BINARY_H__
#define __TO_BINARY_H__

#include<iostream>
#include<cv.h>
#include<highgui.h>
#include "class.h"
using namespace std;
using namespace cv;
IplImage* to_binary(IplImage* binary_t);
#endif


