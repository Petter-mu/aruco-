#include "cvdrawingutils.h"
#include <iostream>
#include <fstream>
#include <cmath>

#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <fractaldetector.h>
#include "aruco_cvversioning.h"
using namespace std;
using namespace cv;
//int fractal_dectect( cv::Mat im);
int fractal_dectect( cv::Mat im)
{
  
   
   aruco::FractalDetector FDetector;
   FDetector.setConfiguration("FRACTAL_4L_6");
   if(FDetector.detect(im)){
       FDetector.drawMarkers(im);
   }
   FDetector.draw2d(im); //Show me the inner corners!
   resize(im, im, Size(im.cols/2, im.rows/2));
   cv::imshow("fractal_dectect_image",im);
   cout<<"fractal_dectect is end"<<endl;
   //cv::imwrite("adf.png",im);
   //cv::waitKey(0);
}
