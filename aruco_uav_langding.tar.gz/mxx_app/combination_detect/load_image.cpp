#include<iostream>
#include<cv.h>
#include<highgui.h>
using namespace std;
using namespace cv;
IplImage* load_image(char* str);
IplImage* load_image(char* str)
{
	 //IplImage*  src = cvLoadImage ("marker_result.jpg", 1);
	 IplImage*  src = cvLoadImage (str, 1);
	 IplImage *dst;
	 CvSize size;
	 double scale = 0.5;     //缩放的倍数
	 size.width = src->width*scale;
	 size.height = src->height*scale;
	 dst = cvCreateImage(size, src->depth, src->nChannels);
	 cvResize(src, dst, CV_INTER_CUBIC);

     cvNamedWindow("src_image",CV_WINDOW_AUTOSIZE);
	 cvShowImage("src_image",dst);
	 return dst;
}
