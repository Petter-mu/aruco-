#ifndef __TO_GRAY_H__
#define __TO_GRAY_H__
#include<iostream>
#include<cv.h>
#include<highgui.h>
#include "class.h"
using namespace std;
using namespace cv;
IplImage* to_gray(IplImage* gray_t);
#endif


