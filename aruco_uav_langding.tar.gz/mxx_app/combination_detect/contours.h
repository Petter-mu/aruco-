#ifndef __CONTOURS_H__
#define __CONTOURS_H__


#include<iostream>
#include<cv.h>
#include<highgui.h>
#include "class.h"
using namespace std;
using namespace cv;
typedef struct
{
 vector<Point> squares_centers;
 vector< vector<Point> > squares_v;
	
}ex_conutour;
ex_conutour extract_contours(IplImage* img,IplImage* src_contour);

#endif