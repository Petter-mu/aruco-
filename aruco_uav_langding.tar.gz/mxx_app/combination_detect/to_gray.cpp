#include<iostream>
#include<cv.h>
#include<highgui.h>


using namespace std;
using namespace cv;
IplImage* to_gray(IplImage* gray_t)
{
	IplImage* img = cvCreateImage (cvGetSize(gray_t), IPL_DEPTH_8U, 1);
	cvCvtColor (gray_t, img, CV_BGR2GRAY);//ת�Ҷ�
    cvNamedWindow("gray",CV_WINDOW_AUTOSIZE);
	cvShowImage("gray",img);
	return img;
}

