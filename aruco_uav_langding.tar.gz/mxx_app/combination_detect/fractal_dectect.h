#ifndef __FRACTAL_DECTECT_H__
#define __FRACTAL_DECTECT_H__

#include "cvdrawingutils.h"
#include <iostream>
#include <fstream>
#include <cmath>

#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <fractaldetector.h>
#include "aruco_cvversioning.h"
using namespace std;
using namespace cv;
int fractal_dectect( cv::Mat im);
#endif
