#include<iostream>
#include<cv.h>
#include<highgui.h>


using namespace std;
using namespace cv;
IplImage* to_binary(IplImage* binary_t)
{
	cvThreshold (binary_t, binary_t, 0, 255, CV_THRESH_OTSU);	//OSTU二值化
	cvNamedWindow("OSTU",CV_WINDOW_AUTOSIZE);
	cvShowImage("OSTU",binary_t);
	 return binary_t;
}

