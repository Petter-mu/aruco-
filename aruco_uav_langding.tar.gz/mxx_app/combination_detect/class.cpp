﻿#include<iostream>
#include<cv.h>
#include<highgui.h>


using namespace std;
using namespace cv;

/*
void on_mouse( int event, int x, int y, int flags, void* ustc)  
{  
CvFont font;  
cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX, 0.5, 0.5, 0, 1, CV_AA);  
if( event == CV_EVENT_MOUSEMOVE )  
{  
cvCopy(dst,src);  
CvPoint pt = cvPoint(x,y);  
char temp[16];
sprintf(temp,"(%d,%d)",pt.x,pt.y);  
cvPutText(src,temp, pt, &font, cvScalar(255, 255, 255, 0));  
cvCircle( src, pt, 2,cvScalar(255,0,0,0) ,CV_FILLED, CV_AA, 0 );  
cvShowImage( "src", src );  
}   
}  

*/


double ComputeDistance(Point &point1,Point &point2)
{
	return 	sqrtf(powf((point1.x - point1.x),2) + powf((point1.y - point2.y),2));  

}

IplImage* CenterClassification( vector<Point> &squares_centers_class,vector< vector<Point> > squares_v, vector< vector<int> > &result_class,IplImage* src)
{
	int index_i;
	int index_j;
	int temp_num=0;
	vector<int> centers_index;
	vector<int> result_temp;
	vector<Point> corner_v;
	
	
	Point temp;
	CvPoint corner[4];
	
	IplImage* src_c = cvCreateImage (cvGetSize(src), src->depth, src->nChannels);
	cvCopy(src,src_c,NULL);
	
	
	for(int i = 0; i < squares_centers_class.size(); i++)
	{
		centers_index.push_back(i);    //save the index of squares centers
	}

	for(int i = 0; i < centers_index.size(); i++)
	{
		result_temp.push_back(centers_index[i]);
		for(int j = i + 1; j < centers_index.size(); j++)
		{
			index_i = centers_index[i];
			index_j = centers_index[j];
			double dis=ComputeDistance( squares_centers_class[index_i], squares_centers_class[index_j] );
			//cout<<dis<<endl;
			if( dis< 5 )	 //小于5像素，是同一类矩形；
			{
				result_temp.push_back(centers_index[j]);
				centers_index.erase(centers_index.begin() + j - 1);
				j--;
			}
		}
		//cout<<endl;
		result_class.push_back(result_temp);
		result_temp.clear();
	}
	int temp_num_index=0;
	for (int i=0;i<result_class.size();i++)
	{
		if(temp_num<result_class[i].size())		//	 temp_num是出现次数最多的矩形,即是同一个矩形；
		{										//  temp_num_index 在检测到矩形中 找到 次数最多的那一个矩形的角标；  
		   temp_num=result_class[i].size();
			temp_num_index=i;
		}
			

	}
	cout<<"************************"<<endl;
	cout<<"************************"<<endl;
	cout<<"************************"<<endl;
	cout<<"The flitered contours is...."<<endl;
	for (int i=0;i<result_class[temp_num_index].size();i++)	 //代表画几个符合要求的矩形
	{
		//cout<<result_class[temp_num_index].size()<<endl;
		corner[0].x=squares_v[result_class[temp_num_index][i]][0].x;
		corner[0].y=squares_v[result_class[temp_num_index][i]][0].y;
		corner[1].x=squares_v[result_class[temp_num_index][i]][1].x;
		corner[1].y=squares_v[result_class[temp_num_index][i]][1].y;
		corner[2].x=squares_v[result_class[temp_num_index][i]][2].x;
		corner[2].y=squares_v[result_class[temp_num_index][i]][2].y;
		corner[3].x=squares_v[result_class[temp_num_index][i]][3].x;
		corner[3].y=squares_v[result_class[temp_num_index][i]][3].y;
		for(int i =0; i < 4; i++)    //save the corner points to corner_v, it will help us process the data
		{
			temp = corner[i];
			corner_v.push_back(temp);
		}
		cvLine(src_c,corner[0],corner[1],cvScalar(0, 255, 0),1,CV_AA,0);
		cvLine(src_c,corner[1],corner[2],cvScalar(0, 255, 0),1,CV_AA,0);
		cvLine(src_c,corner[2],corner[3],cvScalar(0, 255, 0),1,CV_AA,0);
		cvLine(src_c,corner[3],corner[0],cvScalar(0, 255, 0),1,CV_AA,0);
		cout<<"The corner_v NO.1 point is"<<corner_v[0]<<endl;
		cout<<"The corner_v NO.2 is"<<corner_v[1]<<endl;
		cout<<"The corner_v NO.3 is"<<corner_v[2]<<endl;
		cout<<"The corner_v NO.4 is"<<corner_v[3]<<endl;
		cout<<endl;
		cout<<"The centers_point is ["<<(corner_v[0].x+corner_v[1].x+corner_v[2].x+corner_v[3].x)/4;
		cout<<","<<(corner_v[0].y+corner_v[1].y+corner_v[2].y+corner_v[3].y)/4<<"]"<<endl;
		
		corner_v.clear();
		cout<<"*************"<<endl;
	}
	cvNamedWindow ("Flitered Contour", 1);
	cvShowImage ("Flitered Contour", src_c);
	return src_c;

}