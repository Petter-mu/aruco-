

#include "opencv2/opencv.hpp"
#include <opencv2/aruco.hpp>
#include <iostream>
#include <vector>

using namespace std;
using namespace cv;
using namespace aruco;
int main(int argc, char** argv)
{
    Mat image=imread(argv[1]);
    resize(image,image,Size(640,480));
    Mat imageCopy;
    image.copyTo(imageCopy);
    Ptr<aruco::Dictionary> dictionary =getPredefinedDictionary(cv::aruco::DICT_6X6_250);
    
    std::vector<int> ids;
    std::vector<std::vector<cv::Point2f> > corners;
    cv::aruco::detectMarkers(image, dictionary, corners, ids);
    // if at least one marker detected
    cout<<"num "<<ids.size()<<endl;
    for (std::vector<vector<Point2f>>::iterator i = corners.begin(); i != corners.end(); ++i)
    {
        cout<<*i<<endl;
        // int c_cnt=0;
        // if(c_cnt++ == 4)
        // {
        //     c_cnt=0;
        cout<<endl;
        // }
        
    }
    Mat cameraMatrix=(Mat_<double>(3,3)<<6.2368591898095463e+02, 0., 3.2098359853885842e+02, 
                                         0.,6.2116765573821158e+02, 2.5072889265884095e+02, 
                                         0., 0., 1.);
    //double dist[4]={0.06108,-0.11259,-0.00508,0.00425};
    //vector<double>  distCoeffs(dist,dist+4);
    Mat distCoeffs=(Mat_<double>(1,5)<<-1.5456526440839858e-02, 2.0454612517925752e-01,
                                        3.1873842377836515e-04, 5.6944183910163937e-04,
                                        -5.1552022204782377e-01);
    if (ids.size() > 0)
    {
        cout<<"num "<<ids.size()<<endl;
        cv::aruco::drawDetectedMarkers(imageCopy, corners, ids);
        vector< Vec3d > rvecs, tvecs;
        cv::aruco::estimatePoseSingleMarkers(corners, 0.063, cameraMatrix, distCoeffs, rvecs, tvecs);
        // draw axis for each marker
        for(int i=0; i<ids.size(); i++)
            {
                cout<<"Marker NO."<<i<<" is "<<ids[i]<<endl;
                cout<<"The detected marker is N0."<<i<<endl;
                cout<<"The Rvec Matrix is"<<rvecs[i]<<endl;
                cout<<"The Tvec Matrix is"<<tvecs[i]<<endl;
                cv::aruco::drawAxis(imageCopy, cameraMatrix, distCoeffs, rvecs[i], tvecs[i], 0.05);
                cout<<endl;
            }
    }
    cv::imshow("out", imageCopy);
    waitKey(0);
    return 0;
}
