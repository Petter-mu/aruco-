#include <iostream>
#include <string.h>
#include <opencv2/opencv.hpp>  
#include <opencv2/highgui/highgui.hpp>  
#include <stdexcept>
#include <opencv2/imgproc/imgproc.hpp>
#include "aruco.h"
#include <string.h>
using namespace std;
using namespace cv;
using namespace aruco;

int main(int argc,char** argv)
{
    char* name1=argv[1];
    char name[strlen(name1)]={0};
    strncpy(name,name1,(strlen(name1)-4));
     cout<<name<<endl;
     strcat(name,"result");
    strcat(name,".jpg");
    cout<<name<<endl;
    Mat image=imread(argv[1]);
    MarkerDetector MDetector;
    resize(image,image,Size(640,480));
    Mat imageCopy;
    image.copyTo(imageCopy);
    std::vector<Marker> Markers = MDetector.detect(image);
  
   for (unsigned int i = 0; i < Markers.size(); i++)
        {
            cout << Markers[i] << endl;
            /*
              void draw(cv::Mat& in, cv::Scalar color=cv::Scalar(0,0,255), int lineWidth = -1, bool writeId = true,bool 	      writeInfo=false) const;
              para1:ipput image;
              para2: color of drawing;
              para3: width of line of drawing;
            */
            Markers[i].draw(image, Scalar(0, 0, 255), 1);//cvScalar的储存顺序是B-G-R
        }
    //cv::imshow("out", image);
    cv::namedWindow("in", 1);
    cv::imshow("in", image);
   // cv::waitKey(0);   
        while(cv::waitKey(0) == 115)
        {
           
                imwrite(name, image);
                  return 0;
        }
        return 0;
            
         
}
