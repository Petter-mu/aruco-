#include "aruco.h"
#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <string.h>
//#include "arucofidmarkers.h"
using namespace cv;

using namespace std;
int main(int argc,char* argv[])
{
    Mat markerImage;
    char *format=argv[1];
        cout<<format<<endl;
    int id=atoi(argv[1]);
    strcat(format,".jpg");
    cout<<format<<endl;
    //Ptr<aruco::Dictionary> dictionary =getPredefinedDictionary(cv::aruco::DICT_6X6_250);
    //drawMarker( dictionary,27, 200, markerImage, 1);
    //markerImage = aruco::FiducidalMarkers::createMarkerImage(27, 500, true,false); 
    /*
       returns the image of the marker indicated by its id. It the id is not, returns empty matrix
       @param id of the marker image to return
       @param bit_size of the image will be  AxA, A=(nbits()+2)*bit_size
       @param d is 水印
       @param enclosed_corners if true, extra rectagles are added touching the marker corners. it can be used to
       allow subpixel refinement
       **************
       **************
       **************
       cv::Mat getMarkerImage_id(int id, int bit_size, bool d = true, bool enclosed_corners = false,bool printExternalWhiteBorder=false,bool centralCircle=false);

    */
    aruco::Dictionary dic = aruco::Dictionary::load("ARUCO_MIP_36h12");
    cv::Mat image=dic.getMarkerImage_id(id, 75, true,false,false,false);
    cv::imshow("in", image);
    cv::imwrite(format, image);   
    waitKey(0);
    return 0;
}
