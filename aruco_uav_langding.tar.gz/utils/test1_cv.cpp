#include "opencv2/opencv.hpp"
#include <opencv2/aruco.hpp>
#include<iostream>
#include<string.h>
using namespace cv;
using namespace aruco;
int main(int argc,char **argv)
{
    Mat markerImage;

    char* format=argv[1];//*argv+1=argv[1];即第一个参数的地址；
    cv::Ptr<aruco::Dictionary> dictionary =getPredefinedDictionary(cv::aruco::DICT_6X6_250);

   strcat(format,".jpg");
   std::cout<< format<<std::endl;
   drawMarker( dictionary,*argv[1], 250, markerImage, 1);
    //sprintf(szName, "./%d.jpg", (int)*argv[1]);//设置保存路径  
   
    imshow("marker",markerImage);
    imwrite(format,markerImage);
    waitKey(0);
    return 0;
}
