#include "opencv2/opencv.hpp"
#include <opencv2/aruco.hpp>
#include <iostream>
#include <pthread.h>
#include <stdio.h>  
#include <string.h>
#include <math.h>  
#include <string.h>
#include <unistd.h>
#include "highgui.h"  
#include <cv.h>  
#include <opencv2/opencv.hpp>  
#include <opencv2/highgui/highgui.hpp>  
using namespace std;
using namespace cv;
using namespace aruco;
int main(int argc,char *argv[])
{
    Mat image=imread(argv[1]);
    resize(image,image,Size(640,480));
    Mat imageCopy;
    image.copyTo(imageCopy);
    Ptr<aruco::Dictionary> dictionary =getPredefinedDictionary(cv::aruco::DICT_6X6_250);
    std::vector<int> ids;
    std::vector<std::vector<cv::Point2f> > corners;
    cv::aruco::detectMarkers(image, dictionary, corners, ids);
    // if at least one marker detected
    cout<<"num "<<ids.size()<<endl;
    if (ids.size() > 0)
    {
        cout<<"num "<<ids.size()<<endl;
        cv::aruco::drawDetectedMarkers(imageCopy, corners, ids);
    }

    cv::imshow("out", imageCopy);
    waitKey(0);
    return 0;
}
