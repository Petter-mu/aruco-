#include "cvdrawingutils.h"
#include <iostream>
#include <fstream>
#include <cmath>

#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <fractaldetector.h>
#include "aruco_cvversioning.h"
using namespace std;
using namespace cv;
int main(int argc,char **argv)
{
   if(argc==1)
   {
      cout<<"usage_[please picture.jpg]"<<endl;
      return 0;
   }
   cv::Mat im=cv::imread(argv[1]);
   resize(im, im, Size(im.cols/2, im.rows/2));
   aruco::FractalDetector FDetector;
   FDetector.setConfiguration("FRACTAL_4L_6");
   if(FDetector.detect(im)){
       FDetector.drawMarkers(im);
   }
   FDetector.draw2d(im); //Show me the inner corners!

   cv::imshow("image",im);
   //cv::imwrite("adf.png",im);
   cv::waitKey(0);
}
